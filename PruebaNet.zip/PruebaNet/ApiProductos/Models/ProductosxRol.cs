﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiProductos.Models
{
    public class ProductosxRol
    {
        public string rol { get; set; }
        public string producto { get; set; }
    }
}
