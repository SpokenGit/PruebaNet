﻿using ApiProductos.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiProductos.Controllers
{
    [ApiController]
    [Route("productos")]
    public class ProductosController :ControllerBase
    {
        [HttpGet]
        [Route("ProductosxRol")]
        public List<ProductosxRol> ProductosxRol(string rol)
        {

            List<ProductosxRol> productosxrol = new List<ProductosxRol>
            {
                new ProductosxRol{ rol="Principal", producto="Prod_A" },
                new ProductosxRol{ rol="Principal", producto="Prod_B" },
                new ProductosxRol{ rol="Principal", producto="Prod_C" },
                new ProductosxRol{ rol="Delegado", producto="Prod_A" },
                new ProductosxRol{ rol="Delegado", producto="Prod_C" }
            };

            try { return productosxrol.Where(x => x.rol == rol).ToList(); }
            catch { return null; }
            
        }
    }
}
