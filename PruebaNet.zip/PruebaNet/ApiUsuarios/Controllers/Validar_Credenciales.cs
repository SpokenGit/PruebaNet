﻿using ApiUsuarios.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiUsuarios.Controllers
{

    [ApiController]
    [Route("seguridad")]
    public class Validar_Credenciales : ControllerBase
    {

        [HttpGet]
        [Route("ValidarCredenciales")]
        public bool ValidarCredenciales(string usuario , string pass)
        {

            List<Credenciales> credenciales = new List<Credenciales> {
            new Credenciales{
            usuario = "User1",
            password ="Clave1"
            },
            new Credenciales{
            usuario ="User2",
            password="Clave2"
            }
            };

            try {
                if (credenciales.Where(x => x.usuario == usuario.Trim() && x.password == pass.Trim()).Count()>0)
                    return true;
                else return false;    
            
            } 
            catch { return false; }
           
        }


        [HttpGet]
        [Route("ObtenerRolesUsuario")]
        public string ObtenerRolesUsuario(string user)
        {

            
            List<Rolesusuario> Roles = new List<Rolesusuario> {
            new Rolesusuario{
            usuario = "User1",
            rol ="Principal"
            },
            new Rolesusuario{
            usuario ="User2",
            rol="Delegado"
            }
            };

            try { return Roles.Where(x => x.usuario == user).Select(x=> x.rol).FirstOrDefault(); }
            catch { return null; }
            
        }


    }
}
