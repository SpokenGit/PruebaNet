﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiUsuarios.Models
{
    public class Rolesusuario
    {
        public string usuario { get; set; }
        public string rol { get; set; }
    }
}
