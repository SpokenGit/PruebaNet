﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using WebFrontEnd.Models;

namespace WebFrontEnd.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        { return View(); }



        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(Account usuario)
        {
            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
            try
            {
                string UserExist = ExecuteRequest("https://localhost:44364/seguridad/ValidarCredenciales?usuario=" + usuario.userlogged + "&pass=" + usuario.password + "");
               

                if (UserExist.Contains("true"))
                {
                    string Role = ExecuteRequest("https://localhost:44364/seguridad/ObtenerRolesUsuario?user=" + usuario.userlogged );

                    //******************Agregando el Claim*******************
                    var identity = new ClaimsIdentity(new[] {
                        new Claim(ClaimTypes.Name, usuario.userlogged),
                        new Claim(ClaimTypes.Role,Role)
                         }, CookieAuthenticationDefaults.AuthenticationScheme);

                    var principal = new ClaimsPrincipal(identity);

                    var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal,
                        new AuthenticationProperties
                        {
                            ExpiresUtc = DateTime.UtcNow.AddMinutes(20),
                            IsPersistent = false,
                            AllowRefresh = false
                        });
                    //********************************************************

                    return RedirectToAction("Index", "Product");
                }
                else
                {
                    //Error en pantalla
                    return View();
                }
                
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to retrieve asset from : " + ex.Message, ex);
              
            }

           
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }




        public string ExecuteRequest(string request)
        {
            try {

                Byte[] bytes;
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(request);
                webRequest.KeepAlive = true;
                webRequest.ProtocolVersion = HttpVersion.Version10;
                webRequest.ServicePoint.ConnectionLimit = 24;
                webRequest.Headers.Add("UserAgent", "Pentia; MSI");
                using (WebResponse webResponse = webRequest.GetResponse())
                {
                    string contentType = webResponse.ContentType;
                    using (Stream stream = webResponse.GetResponseStream())
                    {
                        using (MemoryStream memoryStream = new MemoryStream())
                        {
                            // Stream the response to a MemoryStream via the byte array buffer
                            Byte[] buffer = new Byte[0x1000];
                            Int32 bytesRead;
                            while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                            {
                                memoryStream.Write(buffer, 0, bytesRead);
                            }
                            return System.Text.Encoding.UTF8.GetString(buffer, 0, buffer.Length);
                        }
                    }
                }

            } 
            catch(Exception ex) {
                return "Error " + ex.Message;
            }
           
        }


    }
}
